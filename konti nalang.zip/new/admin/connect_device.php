<?php
$pdo = new PDO("mysql:host=localhost;dbname=nookie", "root", "");

$id = $_GET['id'];

// Get device info
$stmt = $pdo->prepare("SELECT * FROM biometric_devices WHERE id=?");
$stmt->execute([$id]);
$device = $stmt->fetch();

$ip = $device['ip_address'];
$port = $device['port'];

/* ================= CONNECT TO BIOMETRIC ================= */

/*
   Replace this with REAL SDK connection
   Example: ZKTeco PHP Library
*/

function connectBiometric($ip, $port) {
    $socket = @fsockopen($ip, $port, $errno, $errstr, 5);

    if ($socket) {
        fclose($socket);
        return true;
    }
    return false;
}

if (connectBiometric($ip, $port)) {

    // Update status
    $pdo->prepare("UPDATE biometric_devices SET status='connected' WHERE id=?")->execute([$id]);

    echo "<h3 style='color:green;'>Device Connected Successfully!</h3>";

} else {

    $pdo->prepare("UPDATE biometric_devices SET status='disconnected' WHERE id=?")->execute([$id]);

    echo "<h3 style='color:red;'>Connection Failed!</h3>";
}

echo "<br><a href='bio_connect.php'>Back</a>";
?>