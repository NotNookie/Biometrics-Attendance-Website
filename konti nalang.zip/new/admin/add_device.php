<?php
$pdo = new PDO("mysql:host=localhost;dbname=nookie", "root", "");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['device_name'];
    $ip = $_POST['ip_address'];
    $port = $_POST['port'];

    $stmt = $pdo->prepare("INSERT INTO biometric_devices (device_name, ip_address, port) VALUES (?, ?, ?)");
    $stmt->execute([$name, $ip, $port]);

    header("Location: bio_connect.php");
}
?>

<form method="POST">
    <h2>Add Biometric Device</h2>

    Device Name:<br>
    <input type="text" name="device_name" required><br><br>

    IP Address:<br>
    <input type="text" name="ip_address" required><br><br>

    Port:<br>
    <input type="number" name="port" value="4370"><br><br>

    <button type="submit">Save Device</button>
</form>