<?php

declare(strict_types=1);

session_start();

/* ================= AUTH ================= */
if (!isset($_SESSION['admin_name']) || trim((string) $_SESSION['admin_name']) === '') {
    header('Location: login.php');
    exit;
}

$adminName = trim((string) $_SESSION['admin_name']);

/* ================= DB CONNECTION ================= */
$pdo = new PDO("mysql:host=localhost;dbname=nookie;charset=utf8", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/* ================= FUNCTIONS ================= */
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function generateEmployeeKey(int $length = 6): string
{
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $key = '';
    for ($i = 0; $i < $length; $i++) {
        $key .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $key;
}

function formatTime(?string $time): string
{
    if (!$time) return '-';
    return date('h:i A', strtotime($time));
}

/* ================= AJAX: GET POSITIONS ================= */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'positions') {
    header('Content-Type: application/json');

    $departmentId = (int)($_GET['department_id'] ?? 0);

    if ($departmentId > 0) {
        $stmt = $pdo->prepare("SELECT id, position_name FROM positions WHERE department_id = ? ORDER BY position_name ASC");
        $stmt->execute([$departmentId]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    } else {
        echo json_encode([]);
    }
    exit;
}

/* ================= HANDLE ADD DEPARTMENT ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_department'])) {
    $departmentName = trim((string)($_POST['department_name'] ?? ''));

    if ($departmentName !== '') {
        $checkDept = $pdo->prepare("SELECT COUNT(*) FROM departments WHERE department_name = ?");
        $checkDept->execute([$departmentName]);

        if ((int)$checkDept->fetchColumn() === 0) {
            $stmt = $pdo->prepare("INSERT INTO departments (department_name) VALUES (?)");
            $stmt->execute([$departmentName]);

            header("Location: employees.php?success=department_added");
            exit;
        } else {
            header("Location: employees.php?error=department_exists");
            exit;
        }
    }
}

/* ================= HANDLE ADD POSITION ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_position'])) {
    $departmentId = (int)($_POST['department_id'] ?? 0);
    $positionName = trim((string)($_POST['position_name'] ?? ''));

    if ($departmentId > 0 && $positionName !== '') {
        $checkPos = $pdo->prepare("SELECT COUNT(*) FROM positions WHERE department_id = ? AND position_name = ?");
        $checkPos->execute([$departmentId, $positionName]);

        if ((int)$checkPos->fetchColumn() === 0) {
            $stmt = $pdo->prepare("INSERT INTO positions (department_id, position_name) VALUES (?, ?)");
            $stmt->execute([$departmentId, $positionName]);

            header("Location: employees.php?success=position_added");
            exit;
        } else {
            header("Location: employees.php?error=position_exists");
            exit;
        }
    }
}

/* ================= HANDLE ADD EMPLOYEE ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_employee'])) {
    $name         = trim((string)($_POST['name'] ?? ''));
    $department   = trim((string)($_POST['department'] ?? ''));
    $position     = trim((string)($_POST['position'] ?? ''));
    $email        = trim((string)($_POST['email'] ?? ''));
    $mobile       = trim((string)($_POST['mobile'] ?? ''));
    $shiftIn      = trim((string)($_POST['shift_in'] ?? ''));
    $shiftOut     = trim((string)($_POST['shift_out'] ?? ''));
    $status       = trim((string)($_POST['status'] ?? 'Active'));

    if (
        $name !== '' &&
        $department !== '' &&
        $position !== '' &&
        $email !== '' &&
        $mobile !== '' &&
        $shiftIn !== '' &&
        $shiftOut !== ''
    ) {
        do {
            $employeeKey = generateEmployeeKey(6);
            $check = $pdo->prepare("SELECT COUNT(*) FROM employees WHERE employee_key = ?");
            $check->execute([$employeeKey]);
        } while ((int)$check->fetchColumn() > 0);

        $stmt = $pdo->prepare("
            INSERT INTO employees 
            (employee_key, name, department, position, email, mobile, shift_in, shift_out, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $employeeKey,
            $name,
            $department,
            $position,
            $email,
            $mobile,
            $shiftIn,
            $shiftOut,
            $status
        ]);

        header("Location: employees.php?success=added");
        exit;
    }
}

/* ================= HANDLE DELETE EMPLOYEE ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_employee'])) {
    $employeeId = trim((string)($_POST['employee_key'] ?? ''));

    if ($employeeId !== '') {
        $stmt = $pdo->prepare("DELETE FROM employees WHERE employee_key = ?");
        $stmt->execute([$employeeId]);

        header("Location: employees.php?success=deleted");
        exit;
    }
}

/* ================= HANDLE UPDATE EMPLOYEE ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_employee'])) {
    $employeeId   = trim((string)($_POST['employee_key'] ?? ''));
    $name         = trim((string)($_POST['name'] ?? ''));
    $department   = trim((string)($_POST['department'] ?? ''));
    $position     = trim((string)($_POST['position'] ?? ''));
    $email        = trim((string)($_POST['email'] ?? ''));
    $mobile       = trim((string)($_POST['mobile'] ?? ''));
    $shiftIn      = trim((string)($_POST['shift_in'] ?? ''));
    $shiftOut     = trim((string)($_POST['shift_out'] ?? ''));
    $status       = trim((string)($_POST['status'] ?? 'Active'));

    if (
        $employeeId !== '' &&
        $name !== '' &&
        $department !== '' &&
        $position !== '' &&
        $email !== '' &&
        $mobile !== '' &&
        $shiftIn !== '' &&
        $shiftOut !== ''
    ) {
        $stmt = $pdo->prepare("
            UPDATE employees
            SET name = ?, department = ?, position = ?, email = ?, mobile = ?, shift_in = ?, shift_out = ?, status = ?
            WHERE employee_key = ?
        ");
        $stmt->execute([
            $name,
            $department,
            $position,
            $email,
            $mobile,
            $shiftIn,
            $shiftOut,
            $status,
            $employeeId
        ]);

        header("Location: employees.php?success=updated");
        exit;
    }
}

/* ================= LOAD DEPARTMENTS ================= */
$deptStmt = $pdo->query("SELECT id, department_name FROM departments ORDER BY department_name ASC");
$departments = $deptStmt->fetchAll(PDO::FETCH_ASSOC);

/* ================= SEARCH / FILTER ================= */
$search = trim((string)($_GET['search'] ?? ''));
$statusFilter = trim((string)($_GET['status'] ?? ''));

$sql = "SELECT * FROM employees WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND (name LIKE ? OR employee_key LIKE ? OR department LIKE ? OR position LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($statusFilter !== '' && in_array($statusFilter, ['Active', 'Inactive'])) {
    $sql .= " AND status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY id ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ================= COUNTS ================= */
$totalStmt = $pdo->query("SELECT COUNT(*) FROM employees");
$totalEmployees = (int)$totalStmt->fetchColumn();

$activeStmt = $pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'");
$activeEmployees = (int)$activeStmt->fetchColumn();

$inactiveStmt = $pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'Inactive'");
$inactiveEmployees = (int)$inactiveStmt->fetchColumn();

/* ================= DIALOG ================= */
$dialog = (string) ($_GET['dialog'] ?? '');
if (!in_array($dialog, ['add', 'delete', 'edit', 'department', 'position'], true)) {
    $dialog = '';
}

$employeeName = trim((string) ($_GET['name'] ?? 'Employee Name'));
$employeeId = trim((string) ($_GET['emp_id'] ?? 'EMP0000'));

if ($employeeName === '') {
    $employeeName = 'Employee Name';
}

if ($employeeId === '') {
    $employeeId = 'EMP0000';
}

$editName = trim((string) ($_GET['name'] ?? ''));
$editEmpId = trim((string) ($_GET['emp_id'] ?? ''));
$editDepartment = trim((string) ($_GET['department'] ?? ''));
$editPosition = trim((string) ($_GET['position'] ?? ''));
$editEmail = trim((string) ($_GET['email'] ?? ''));
$editMobile = trim((string) ($_GET['mobile'] ?? ''));
$editShiftIn = trim((string) ($_GET['shift_in'] ?? '08:00'));
$editShiftOut = trim((string) ($_GET['shift_out'] ?? '17:00'));
$editStatus = trim((string) ($_GET['status'] ?? 'Active'));

if ($editName === '') {
    $editName = 'Employee Name';
}

if ($editEmpId === '') {
    $editEmpId = 'EMP0000';
}

if ($editStatus !== 'Active' && $editStatus !== 'Inactive') {
    $editStatus = 'Active';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employees | Biometric Attendance</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;700;800&family=Plus+Jakarta+Sans:wght@500;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/style.css">
</head>
<script>
document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.getElementById("employeeToggle");
  const menu = document.getElementById("employeeMenu");

  toggle.addEventListener("click", function () {
    menu.classList.toggle("show");
  });

  // Auto open if you're inside employees page with dialog
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has('dialog')) {
    menu.classList.add("show");
  }
});
</script>
<body class="<?= $dialog !== '' ? 'modal-open' : '' ?>">
  <div class="dashboard-layout">
    <aside class="dashboard-sidebar">
      <div class="dashboard-brand">
        <div>
          <strong>Attendance</strong>
          <span>System</span>
        </div>
      </div>

       <nav class="dashboard-nav" aria-label="Main Navigation">
        <div class="dashboard-nav-main">
          <a href="dashboard.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 13h8V3H3z"></path><path d="M13 21h8v-6h-8z"></path><path d="M13 3h8v6h-8z"></path><path d="M3 21h8v-6H3z"></path></svg>
            Dashboard
          </a>
          <a href="employees.php" class="dashboard-nav-link active">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><path d="M20 8v6"></path><path d="M23 11h-6"></path></svg>
            Employees
          </a>
          <a href="departments.php" class="dashboard-nav-link">
  <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M3 7h5l2 3h11v10a2 2 0 0 1-2 2H3z"></path>
    <path d="M3 7V5a2 2 0 0 1 2-2h4l2 3"></path>
  </svg>
  Departments
</a>
          <a href="attendance.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><path d="M16 2v4"></path><path d="M8 2v4"></path><path d="M3 10h18"></path><path d="M8 14h3"></path></svg>
            Attendance
          </a>
          <a href="dtr.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><path d="M14 2v6h6"></path><path d="M8 13h8"></path><path d="M8 17h8"></path></svg>
            DTR
          </a>
        </div>
         <a href="bio_connect.php" class="dashboard-nav-link">
  <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <rect x="2" y="7" width="20" height="10" rx="2"></rect>
    <path d="M6 11h.01"></path>
    <path d="M10 11h.01"></path>
    <path d="M14 11h.01"></path>
    <path d="M18 11h.01"></path>
  </svg>
  Connect Hardware
</a>

        <div class="dashboard-nav-bottom">
          <a href="logout.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><path d="M16 17l5-5-5-5"></path><path d="M21 12H9"></path></svg>
            Logout
          </a>
        </div>
      </nav>
    </aside>

    <main class="dashboard-main">
      <header class="dashboard-header">
        <div>
          <h1 class="dashboard-title">Employee List</h1>
          <p class="dashboard-subtitle">Manage your workforce and view employee details</p>
        </div>

        <div class="dashboard-profile-pill">
          <span class="dot" aria-hidden="true"></span>
          Admin: <?= e($adminName) ?>
        </div>
      </header>

      <section class="dashboard-content">

        <?php if (isset($_GET['success']) && $_GET['success'] === 'added'): ?>
          <div style="background:#d1fae5;padding:12px;border-radius:10px;margin-bottom:15px;">Employee added successfully.</div>
        <?php endif; ?>

        <?php if (isset($_GET['success']) && $_GET['success'] === 'deleted'): ?>
          <div style="background:#fee2e2;padding:12px;border-radius:10px;margin-bottom:15px;">Employee deleted successfully.</div>
        <?php endif; ?>

        <?php if (isset($_GET['success']) && $_GET['success'] === 'updated'): ?>
          <div style="background:#dbeafe;padding:12px;border-radius:10px;margin-bottom:15px;">Employee updated successfully.</div>
        <?php endif; ?>

        <?php if (isset($_GET['success']) && $_GET['success'] === 'department_added'): ?>
          <div style="background:#ede9fe;padding:12px;border-radius:10px;margin-bottom:15px;">Department added successfully.</div>
        <?php endif; ?>

        <?php if (isset($_GET['success']) && $_GET['success'] === 'position_added'): ?>
          <div style="background:#dcfce7;padding:12px;border-radius:10px;margin-bottom:15px;">Position added successfully.</div>
        <?php endif; ?>

        <?php if (isset($_GET['error']) && $_GET['error'] === 'department_exists'): ?>
          <div style="background:#fef3c7;padding:12px;border-radius:10px;margin-bottom:15px;">Department already exists.</div>
        <?php endif; ?>

        <?php if (isset($_GET['error']) && $_GET['error'] === 'position_exists'): ?>
          <div style="background:#fef3c7;padding:12px;border-radius:10px;margin-bottom:15px;">Position already exists in this department.</div>
        <?php endif; ?>

        <div class="dashboard-stats stats-3">
          <article class="dashboard-stat-card accent-teal">
            <div class="stat-icon-wrap teal"></div>
            <div>
              <p class="stat-label">Total Employees</p>
              <p class="stat-number"><?= $totalEmployees ?></p>
            </div>
          </article>

          <article class="dashboard-stat-card accent-green">
            <div class="stat-icon-wrap green"></div>
            <div>
              <p class="stat-label">Active</p>
              <p class="stat-number"><?= $activeEmployees ?></p>
            </div>
          </article>

          <article class="dashboard-stat-card accent-slate">
            <div class="stat-icon-wrap slate"></div>
            <div>
              <p class="stat-label">Inactive</p>
              <p class="stat-number"><?= $inactiveEmployees ?></p>
            </div>
          </article>
        </div>

        <article class="dashboard-panel employee-panel">
          <div class="employee-panel-head">
            <h2 class="panel-title">Manage Employees</h2>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
              <a class="qa-btn qa-primary employee-add-btn" href="employees.php?dialog=add">Employee</a>
              <a class="qa-btn" style="background:#111827;color:#fff;" href="employees.php?dialog=department"> Department</a>
              <a class="qa-btn" style="background:#0f766e;color:#fff;" href="employees.php?dialog=position">+ Add Position</a>
            </div>
          </div>

          <form class="employee-toolbar" method="GET" action="employees.php" role="group" aria-label="Employee toolbar">
            <div class="search-input-wrap">
              <input class="input employee-search-input" type="search" name="search" value="<?= e($search) ?>" placeholder="Search name, employee ID, department, position...">
            </div>

            <div class="employee-toolbar-actions">
              <select name="status" aria-label="Status filter">
                <option value="">All Status</option>
                <option value="Active" <?= $statusFilter === 'Active' ? 'selected' : '' ?>>Active</option>
                <option value="Inactive" <?= $statusFilter === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
              </select>
              <button class="qa-btn qa-primary employee-search-btn" type="submit">Search</button>
            </div>
          </form>

          <div class="table-wrap">
            <table class="timecard employee-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Employee ID</th>
                  <th>Department</th>
                  <th>Position</th>
                  <th>Email</th>
                  <th>Mobile</th>
                  <th>Shift In</th>
                  <th>Shift Out</th>
                  <th>Status</th>
                  <th>Tools</th>
                </tr>
              </thead>
              <tbody>
                <?php if (count($employees) > 0): ?>
                  <?php foreach ($employees as $index => $emp): ?>
                    <tr>
                      <td><?= $index + 1 ?></td>
                      <td><?= e($emp['name']) ?></td>
                      <td><?= e($emp['employee_key']) ?></td>
                      <td><?= e($emp['department']) ?></td>
                      <td><?= e($emp['position']) ?></td>
                      <td><?= e($emp['email']) ?></td>
                      <td><?= e($emp['mobile']) ?></td>
                      <td><?= e(formatTime($emp['shift_in'])) ?></td>
                      <td><?= e(formatTime($emp['shift_out'])) ?></td>
                      <td>
                        <span class="badge <?= $emp['status'] === 'Active' ? 'success' : 'slate' ?>">
                          <?= e($emp['status']) ?>
                        </span>
                      </td>
                      <td>
                        <div class="tool-actions">
                          <a class="btn-mini edit"
                             href="employees.php?dialog=edit&emp_id=<?= urlencode($emp['employee_key']) ?>&name=<?= urlencode($emp['name']) ?>&department=<?= urlencode($emp['department']) ?>&position=<?= urlencode($emp['position']) ?>&email=<?= urlencode($emp['email']) ?>&mobile=<?= urlencode($emp['mobile']) ?>&shift_in=<?= urlencode($emp['shift_in']) ?>&shift_out=<?= urlencode($emp['shift_out']) ?>&status=<?= urlencode($emp['status']) ?>">
                             Edit
                          </a>
                          <a class="btn-mini delete"
                             href="employees.php?dialog=delete&emp_id=<?= urlencode($emp['employee_key']) ?>&name=<?= urlencode($emp['name']) ?>">
                             Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="11" style="text-align:center;">No employees found.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <p class="table-footnote">Showing <?= count($employees) ?> of <?= $totalEmployees ?> entries</p>
        </article>
      </section>
    </main>
  </div>

  <?php if ($dialog === 'add'): ?>
    <div class="dialog-overlay" role="dialog" aria-modal="true" aria-labelledby="addDialogTitle">
      <div class="dialog-card">
        <div class="dialog-head">
          <h2 id="addDialogTitle" class="dialog-title">Add New Employee</h2>
          <a class="dialog-close" href="employees.php" aria-label="Close dialog">x</a>
        </div>

        <form id="dialogAddForm" class="dialog-form-grid" method="POST" action="employees.php">
          <label for="dialog_name">Name</label>
          <input class="input" id="dialog_name" name="name" type="text" required>

          <label for="dialog_department">Department</label>
          <select id="dialog_department" name="department" required>
            <option value="">Select Department</option>
            <?php foreach ($departments as $dept): ?>
              <option value="<?= e($dept['department_name']) ?>" data-id="<?= $dept['id'] ?>">
                <?= e($dept['department_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>

          <label for="dialog_position">Position</label>
          <select id="dialog_position" name="position" required>
            <option value="">Select Position</option>
          </select>

          <label for="dialog_email">Email Address</label>
          <input class="input" id="dialog_email" name="email" type="email" required>

          <label for="dialog_mobile">Mobile No.</label>
          <input class="input" id="dialog_mobile" name="mobile" type="text" required>

          <label for="dialog_shift_in">Shift In</label>
          <input class="input" id="dialog_shift_in" name="shift_in" type="time" required>

          <label for="dialog_shift_out">Shift Out</label>
          <input class="input" id="dialog_shift_out" name="shift_out" type="time" required>

          <label for="dialog_status">Status</label>
          <select id="dialog_status" name="status">
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </form>

        <div class="dialog-footer">
          <a class="btn-secondary" href="employees.php">Close</a>
          <button class="btn-primary" type="submit" form="dialogAddForm" name="add_employee">Save</button>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($dialog === 'edit'): ?>
    <div class="dialog-overlay" role="dialog" aria-modal="true" aria-labelledby="editDialogTitle">
      <div class="dialog-card">
        <div class="dialog-head">
          <h2 id="editDialogTitle" class="dialog-title">Edit Employee</h2>
          <a class="dialog-close" href="employees.php" aria-label="Close dialog">x</a>
        </div>

        <form id="dialogEditForm" class="dialog-form-grid" method="POST" action="employees.php">
          <input type="hidden" name="employee_key" value="<?= e($editEmpId) ?>">

          <label for="edit_name">Name</label>
          <input class="input" id="edit_name" name="name" type="text" value="<?= e($editName) ?>" required>

          <label for="edit_emp_id">Employee ID</label>
          <input class="input" id="edit_emp_id" type="text" value="<?= e($editEmpId) ?>" readonly>

          <label for="edit_department">Department</label>
          <input class="input" id="edit_department" name="department" type="text" value="<?= e($editDepartment) ?>" required>

          <label for="edit_position">Position</label>
          <input class="input" id="edit_position" name="position" type="text" value="<?= e($editPosition) ?>" required>

          <label for="edit_email">Email Address</label>
          <input class="input" id="edit_email" name="email" type="email" value="<?= e($editEmail) ?>" required>

          <label for="edit_mobile">Mobile No.</label>
          <input class="input" id="edit_mobile" name="mobile" type="text" value="<?= e($editMobile) ?>" required>

          <label for="edit_shift_in">Shift In</label>
          <input class="input" id="edit_shift_in" name="shift_in" type="time" value="<?= e($editShiftIn) ?>" required>

          <label for="edit_shift_out">Shift Out</label>
          <input class="input" id="edit_shift_out" name="shift_out" type="time" value="<?= e($editShiftOut) ?>" required>

          <label for="edit_status">Status</label>
          <select id="edit_status" name="status">
            <option value="Active" <?= $editStatus === 'Active' ? 'selected' : '' ?>>Active</option>
            <option value="Inactive" <?= $editStatus === 'Inactive' ? 'selected' : '' ?>>Inactive</option>
          </select>
        </form>

        <div class="dialog-footer">
          <a class="btn-secondary" href="employees.php">Cancel</a>
          <button class="btn-primary" type="submit" form="dialogEditForm" name="update_employee">Update Employee</button>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($dialog === 'department'): ?>
    <div class="dialog-overlay" role="dialog" aria-modal="true" aria-labelledby="departmentDialogTitle">
      <div class="dialog-card dialog-card-sm">
        <div class="dialog-head">
          <h2 id="departmentDialogTitle" class="dialog-title">Add Department</h2>
          <a class="dialog-close" href="employees.php" aria-label="Close dialog">x</a>
        </div>

        <form id="dialogDepartmentForm" class="dialog-form-grid" method="POST" action="employees.php">
          <label for="department_name">Department Name</label>
          <input class="input" id="department_name" name="department_name" type="text" placeholder="e.g. Kitchen" required>
        </form>

        <div class="dialog-footer">
          <a class="btn-secondary" href="employees.php">Cancel</a>
          <button class="btn-primary" type="submit" form="dialogDepartmentForm" name="add_department">Save Department</button>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($dialog === 'position'): ?>
    <div class="dialog-overlay" role="dialog" aria-modal="true" aria-labelledby="positionDialogTitle">
      <div class="dialog-card dialog-card-sm">
        <div class="dialog-head">
          <h2 id="positionDialogTitle" class="dialog-title">Add Position</h2>
          <a class="dialog-close" href="employees.php" aria-label="Close dialog">x</a>
        </div>

        <form id="dialogPositionForm" class="dialog-form-grid" method="POST" action="employees.php">
          <label for="position_department_id">Department</label>
          <select id="position_department_id" name="department_id" required>
            <option value="">Select Department</option>
            <?php foreach ($departments as $dept): ?>
              <option value="<?= $dept['id'] ?>"><?= e($dept['department_name']) ?></option>
            <?php endforeach; ?>
          </select>

          <label for="position_name">Position Name</label>
          <input class="input" id="position_name" name="position_name" type="text" placeholder="e.g. Chef" required>
        </form>

        <div class="dialog-footer">
          <a class="btn-secondary" href="employees.php">Cancel</a>
          <button class="btn-primary" type="submit" form="dialogPositionForm" name="add_position">Save Position</button>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($dialog === 'delete'): ?>
    <div class="dialog-overlay" role="dialog" aria-modal="true" aria-labelledby="deleteDialogTitle">
      <div class="dialog-card dialog-card-sm">
        <div class="dialog-head">
          <h2 id="deleteDialogTitle" class="dialog-title">Delete Employee</h2>
          <a class="dialog-close" href="employees.php" aria-label="Close dialog">x</a>
        </div>

        <p class="helper-text">Are you sure you want to remove this employee record?</p>

        <div class="delete-employee-meta" role="group" aria-label="Employee details">
          <div class="meta-item">
            <span class="meta-label">Employee Name</span>
            <strong><?= e($employeeName) ?></strong>
          </div>
          <div class="meta-item">
            <span class="meta-label">Employee ID</span>
            <strong><?= e($employeeId) ?></strong>
          </div>
        </div>

        <form method="POST" action="employees.php">
          <input type="hidden" name="employee_key" value="<?= e($employeeId) ?>">
          <div class="dialog-footer">
            <a class="btn-secondary" href="employees.php">Cancel</a>
            <button class="btn-danger" type="submit" name="delete_employee">Delete</button>
          </div>
        </form>
      </div>
    </div>
  <?php endif; ?>

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const deptSelect = document.getElementById("dialog_department");
      const positionSelect = document.getElementById("dialog_position");

      if (deptSelect && positionSelect) {
        deptSelect.addEventListener("change", function () {
          const selectedOption = deptSelect.options[deptSelect.selectedIndex];
          const departmentId = selectedOption.getAttribute("data-id");

          positionSelect.innerHTML = '<option value="">Loading...</option>';

          if (!departmentId) {
            positionSelect.innerHTML = '<option value="">Select Position</option>';
            return;
          }

          fetch("employees.php?ajax=positions&department_id=" + departmentId)
            .then(response => response.json())
            .then(data => {
              positionSelect.innerHTML = '<option value="">Select Position</option>';

              if (data.length === 0) {
                positionSelect.innerHTML = '<option value="">No positions found</option>';
                return;
              }

              data.forEach(position => {
                const option = document.createElement("option");
                option.value = position.position_name;
                option.textContent = position.position_name;
                positionSelect.appendChild(option);
              });
            })
            .catch(error => {
              console.error("Error loading positions:", error);
              positionSelect.innerHTML = '<option value="">Error loading positions</option>';
            });
        });
      }
    });
  </script>

</body>
</html>