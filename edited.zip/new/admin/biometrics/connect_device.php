<?php
$pdo = new PDO("mysql:host=localhost;dbname=nookie", "root", "");

// Get device ID safely
$id = $_GET['id'] ?? null;

if (!$id) {
    die("Invalid device ID");
}

// Fetch device info
$stmt = $pdo->prepare("SELECT * FROM biometric_devices WHERE id=?");
$stmt->execute([$id]);
$device = $stmt->fetch();

if (!$device) {
    die("Device not found");
}

$ip = $device['ip_address'];
$port = $device['port'];

/* ================= CONNECT TO BIOMETRIC ================= */
require_once('../../zk/ZKLibrary.php');

function connectBiometric($ip, $port) {
    $zk = new ZKLibrary();
    return $zk->connect($ip, $port);
}

// Default values
$status = "Processing...";
$statusColor = "#333";

if (connectBiometric($ip, $port)) {
    $pdo->prepare("UPDATE biometric_devices SET status='connected' WHERE id=?")->execute([$id]);
    $status = "Device Connected Successfully!";
    $statusColor = "green";
} else {
    $pdo->prepare("UPDATE biometric_devices SET status='disconnected' WHERE id=?")->execute([$id]);
    $status = "Connection Failed!";
    $statusColor = "red";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Biometric Connection</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    margin: 0;
    padding: 0;
}

/* Center container */
.container {
    max-width: 500px;
    margin: 80px auto;
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    text-align: center;
}

/* Title */
h2 {
    margin-bottom: 10px;
}

/* Status */
.status {
    font-size: 18px;
    font-weight: bold;
    margin: 20px 0;
}

/* Device info */
.device-info {
    font-size: 14px;
    color: #555;
}

/* Button */
.btn {
    display: inline-block;
    margin-top: 20px;
    padding: 12px 20px;
    background: #007bff;
    color: #fff;
    text-decoration: none;
    border-radius: 8px;
    transition: 0.3s;
}

.btn:hover {
    background: #0056b3;
}

/* Loader */
.loader {
    border: 4px solid #f3f3f3;
    border-top: 4px solid #007bff;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    margin: 20px auto;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    100% { transform: rotate(360deg); }
}

/* Responsive */
@media (max-width: 600px) {
    .container {
        margin: 40px 15px;
        padding: 20px;
    }
}
</style>
</head>

<body>

<div class="container">
    <h2>Biometric Device Connection</h2>

    <div class="device-info">
        <p><strong>IP Address:</strong> <?php echo htmlspecialchars($ip); ?></p>
        <p><strong>Port:</strong> <?php echo htmlspecialchars($port); ?></p>
    </div>

    <!-- Loader -->
    <div id="loader" class="loader"></div>

    <!-- Status -->
    <div id="status" class="status" style="color: <?php echo $statusColor; ?>; display:none;">
        <?php echo $status; ?>
    </div>

    <!-- Back Button -->
    <a href="../bio_connect.php" class="btn">← Back</a>
</div>

<script>
// Simulate loading then show result
window.onload = function() {
    setTimeout(() => {
        document.getElementById("loader").style.display = "none";
        document.getElementById("status").style.display = "block";
    }, 1500); // 1.5 sec loading effect
};
</script>

</body>
</html>