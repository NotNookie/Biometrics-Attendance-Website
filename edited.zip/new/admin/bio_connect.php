<?php
$pdo = new PDO("mysql:host=localhost;dbname=nookie", "root", "");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Biometric Module</title>
    <style>
        body { font-family: Arial; }
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        .btn { padding: 8px 12px; background: green; color: white; text-decoration: none; }
        .btn-connect { background: blue; }
    </style>
     <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
     <div class="app-shell">
    <aside class="sidebar">
      <div class="brand">Attendance System</div>
     <nav class="dashboard-nav" aria-label="Main Navigation">
        <div class="dashboard-nav-main">
          <a href="dashboard.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 13h8V3H3z"></path><path d="M13 21h8v-6h-8z"></path><path d="M13 3h8v6h-8z"></path><path d="M3 21h8v-6H3z"></path></svg>
            Dashboard
          </a>
          <a href="employees.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><path d="M20 8v6"></path><path d="M23 11h-6"></path></svg>
            Employees
          </a>
          <a href="departments.php" class="dashboard-nav-link ">
  <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M3 7h5l2 3h11v10a2 2 0 0 1-2 2H3z"></path>
    <path d="M3 7V5a2 2 0 0 1 2-2h4l2 3"></path>
  </svg>
  Departments
</a>
          <a href="attendance.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><path d="M16 2v4"></path><path d="M8 2v4"></path><path d="M3 10h18"></path><path d="M8 14h3"></path></svg>
            Attendance
          </a>
          <a href="dtr.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><path d="M14 2v6h6"></path><path d="M8 13h8"></path><path d="M8 17h8"></path></svg>
            DTR
          </a>
        </div>
         <a href="bio_connect.php" class="dashboard-nav-link active">
  <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <rect x="2" y="7" width="20" height="10" rx="2"></rect>
    <path d="M6 11h.01"></path>
    <path d="M10 11h.01"></path>
    <path d="M14 11h.01"></path>
    <path d="M18 11h.01"></path>
  </svg>
  Connect Hardware
</a>

        <div class="dashboard-nav-bottom">
          <a href="logout.php" class="dashboard-nav-link">
            <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><path d="M16 17l5-5-5-5"></path><path d="M21 12H9"></path></svg>
            Logout
          </a>
        </div>
      </nav>
    </aside>

    <main class="main-panel">
      <header class="topbar">
        <h1 class="page-title">Admin Dashboard</h1>
        <div class="admin-pill">
          <span class="dot" aria-hidden="true"></span>
          Admin: name
        </div>
      </header>

<h2>Biometric Devices</h2>

<a href="biometrics/add_device.php" class="btn">+ Add Device</a>

<table>
    <tr>
        <th>ID</th>
        <th>Device Name</th>
        <th>IP Address</th>
        <th>Port</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php
    $stmt = $pdo->query("SELECT * FROM biometric_devices");
    while ($row = $stmt->fetch()) {
    ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['device_name'] ?></td>
        <td><?= $row['ip_address'] ?></td>
        <td><?= $row['port'] ?></td>
        <td><?= $row['status'] ?></td>
        <td>
            <a href="biometrics/connect_device.php?id=<?= $row['id'] ?>" class="btn btn-connect">
                Connect Biometrics Hardware
            </a>
        </td>
    </tr>
    <?php } ?>
</table>

</main>
     </div>
     

</body>
</html>