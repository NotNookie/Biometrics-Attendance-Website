<?php
$pdo = new PDO("mysql:host=localhost;dbname=nookie", "root", "");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Biometric Module</title>
    <style>
        body { font-family: Arial; }
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        .btn { padding: 8px 12px; background: green; color: white; text-decoration: none; }
        .btn-connect { background: blue; }
    </style>
     <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
     <div class="app-shell">
    <aside class="sidebar">
      <div class="brand">Attendance System</div>
      <nav class="nav-group">
        <a href="dashboard.php" class="nav-link active">Dashboard</a>
        <a href="employees.php" class="nav-link">Employees</a>
        <a href="attendance.php" class="nav-link">Attendance</a>
        <a href="dtr.php" class="nav-link">DTR</a>
        <a href="/bio_connect.php" class="nav-link">Connect Biometrics Hardware (i.e ZTecko)</a>
        <a href="logout.php" class="nav-link">Logout</a>
      </nav>
    </aside>

    <main class="main-panel">
      <header class="topbar">
        <h1 class="page-title">Admin Dashboard</h1>
        <div class="admin-pill">
          <span class="dot" aria-hidden="true"></span>
          Admin: name
        </div>
      </header>

<h2>Biometric Devices</h2>

<a href="add_device.php" class="btn">+ Add Device</a>

<table>
    <tr>
        <th>ID</th>
        <th>Device Name</th>
        <th>IP Address</th>
        <th>Port</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php
    $stmt = $pdo->query("SELECT * FROM biometric_devices");
    while ($row = $stmt->fetch()) {
    ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['device_name'] ?></td>
        <td><?= $row['ip_address'] ?></td>
        <td><?= $row['port'] ?></td>
        <td><?= $row['status'] ?></td>
        <td>
            <a href="connect_device.php?id=<?= $row['id'] ?>" class="btn btn-connect">
                Connect Biometrics Hardware
            </a>
        </td>
    </tr>
    <?php } ?>
</table>
</main>
     </div>

</body>
</html>